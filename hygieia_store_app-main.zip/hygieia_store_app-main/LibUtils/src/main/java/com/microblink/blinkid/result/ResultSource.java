package com.microblink.blinkid.result;

public enum ResultSource {

    MIXED,
    NONEMPTY,
    FRONT,
    BACK,
    MRZ,
    BARCODE,
    LOCATIONS
}

package com.example.hygieiamerchant.data_classes

class Customer(
    val id : String = "",
    val name : String = "",
    val currentBalance : Double = 0.0
)
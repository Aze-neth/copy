package com.example.hygieiamerchant.data_classes

class Lgu(
    var id : String = "",
    val name : String = "",
    val address: HashMap<Any?, Any?> = hashMapOf()
)
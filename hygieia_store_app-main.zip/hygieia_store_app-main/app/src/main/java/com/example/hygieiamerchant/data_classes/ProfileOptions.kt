package com.example.hygieiamerchant.data_classes

class ProfileOptions(
    val optionIcon : Int = 0,
    val optionTitle : String = ""
)
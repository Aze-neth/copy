package com.example.hygieiamerchant.data_classes

class RedeemedRewards(
    var name : String = "",
    var discountedPrice : Double = 0.0,
    var discount : Double = 0.0,
    var pointsRequired : Double = 0.0,
)